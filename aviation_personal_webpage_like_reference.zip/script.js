const profileData = {
  name: "Nima Tshomo",
  phone: "+97517123456",
  email: "nimatshomo@gmail.com",
  website: window.location.href,
  organisation: "Department of Civil Aviation, Bhutan",
  title: "Aviation Professional | Researcher | Academic",
  address: "Thimphu, Bhutan"
};

document.getElementById("year").textContent = new Date().getFullYear();

const vCard = `BEGIN:VCARD
VERSION:3.0
FN:${profileData.name}
ORG:${profileData.organisation}
TITLE:${profileData.title}
TEL:${profileData.phone}
EMAIL:${profileData.email}
ADR:${profileData.address}
URL:${profileData.website}
END:VCARD`;

new QRCode(document.getElementById("contactQR"), {
  text: vCard,
  width: 110,
  height: 110,
  colorDark: "#061e50",
  colorLight: "#ffffff",
  correctLevel: QRCode.CorrectLevel.H
});
